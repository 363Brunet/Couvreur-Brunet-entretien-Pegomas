<img 
  src={`${process.env.REACT_APP_ASSETS_BASE_URL}/smscwyci_IMG_1124.jpeg`}
  alt="Équipe Couvreur Brunet - Nettoyage professionnel"
  className="w-full h-[400px] object-cover rounded-2xl shadow-xl"
/>