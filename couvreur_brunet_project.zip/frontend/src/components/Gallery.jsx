const assetsBaseUrl = process.env.REACT_APP_ASSETS_BASE_URL;

const projects = [
  {
    id: 1,
    title: "Nettoyage et démoussage toiture ardoises",
    location: "Pégomas",
    before: `${assetsBaseUrl}/9xs77ltl_IMG_1127.jpeg`,
    after: `${assetsBaseUrl}/9xs77ltl_IMG_1127.jpeg`,
    description: "Démoussage complet et traitement hydrofuge d'une toiture en ardoises naturelles"
  },
  {
    id: 2,
    title: "Nettoyage haute pression tuiles",
    location: "Pégomas",
    before: `${assetsBaseUrl}/10h5996l_IMG_1126.jpeg`,
    after: `${assetsBaseUrl}/10h5996l_IMG_1126.jpeg`,
    description: "Nettoyage haute pression et traitement antimousse sur toiture tuiles"
  },
  {
    id: 3,
    title: "Démoussage toiture complète",
    location: "Pégomas",
    before: `${assetsBaseUrl}/i8bmqy5n_IMG_1125.jpeg`,
    after: `${assetsBaseUrl}/i8bmqy5n_IMG_1125.jpeg`,
    description: "Traitement complet antimousse et nettoyage haute pression avec finition hydrofuge"
  }
];