<img 
  src={`${process.env.REACT_APP_ASSETS_BASE_URL}/vmv4xtyr_IMG_1123.jpeg`}
  alt="Professionnel Couvreur Brunet au travail sur toiture"
  className="w-full h-[500px] object-cover"
/>